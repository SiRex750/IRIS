import urllib.request
import os
import sys
import socket
import numpy as np
from charon_v import parse_video

def test_filtering(video_path: str = "mov_bbb.mp4"):
    if not os.path.exists(video_path):
        import pytest
        pytest.skip(f"Test video {video_path} not found")
        
    frames, stats = parse_video(video_path, return_stats=True, adaptive=True)
    actual_candidate_thresh = stats["candidate_thresh_used"]
    
    # Assert all non-first output frames
    # have residual_energy >= actual_candidate_thresh, or are keyframes.
    for f in frames:
        if f["frame_idx"] == 0:
            continue
        if len(f["motion_vectors"]) > 0:
            assert f["residual_energy"] >= actual_candidate_thresh, \
                f"Frame {f['frame_idx']} has energy {f['residual_energy']:.4f} < thresh {actual_candidate_thresh:.4f} but has motion vectors"

def main():
    socket.setdefaulttimeout(5.0)
    url = "https://www.w3schools.com/html/mov_bbb.mp4"
    temp_video = "mov_bbb.mp4"
    is_temp = True
    
    # 1. Download the public domain MP4 file
    print(f"Downloading test video from {url}...")
    try:
        urllib.request.urlretrieve(url, temp_video)
        print("Download successful.")
    except Exception as e:
        print(f"Error downloading test video: {e}")
        if os.path.exists("videoplayback.mp4"):
            temp_video = "videoplayback.mp4"
            is_temp = False
            print("Using local videoplayback.mp4 for testing.")
        else:
            sys.exit(1)
        
    try:
        # 2. Run the parser with return_stats=True (defaults to adaptive=True)
        print("Parsing video in adaptive mode...")
        output, stats = parse_video(temp_video, return_stats=True)
        print(f"Parsing complete. Found {len(output)} output entries out of {stats['total']} total frames.")
        
        # 3. Assertions
        
        # Assert: Output is a list of dicts
        assert isinstance(output, list), "Output must be a list"
        assert all(isinstance(f, dict) for f in output), "All output elements must be dicts"
        
        # Assert: All dicts have the required keys
        required_keys = {"frame_idx", "timestamp", "residual_energy", "motion_vectors"}
        for f in output:
            assert required_keys.issubset(f.keys()), f"Dict missing required keys: {f.keys()}"
            assert "tier" not in f, "Output dict should not contain 'tier' key"
            
        total_frames = stats["total"]
        print(f"Total frame count: {total_frames}")
        
        # Assert: Used thresholds are returned in stats and correctness is verified
        assert "candidate_thresh_used" in stats, "stats missing candidate_thresh_used"
        
        candidate_thresh_default = 0.08
        
        print(f"Adaptive thresholds used: Candidate={stats['candidate_thresh_used']:.4f}")
        assert stats['candidate_thresh_used'] < candidate_thresh_default, f"candidate_thresh_used ({stats['candidate_thresh_used']}) should be less than {candidate_thresh_default}"
        
        # Test adaptive=False behavior
        print("Parsing video with adaptive=False to verify hardcoded thresholds...")
        output_non_adaptive, stats_non_adaptive = parse_video(
            temp_video,
            return_stats=True,
            adaptive=False,
            candidate_thresh=0.08
        )
        assert stats_non_adaptive['candidate_thresh_used'] == 0.08
        
        # Additional assertion: Let's make sure that at least some frames have non-empty motion vectors.
        # By setting adaptive=False and candidate_thresh=0.0, we parse all frames and verify that motion vector extraction works.
        print("Parsing video with candidate_thresh=0.0 to verify motion vectors...")
        all_frames = parse_video(temp_video, candidate_thresh=0.0, adaptive=False)
        has_mvs = any(len(f["motion_vectors"]) > 0 for f in all_frames)
        print(f"Has non-empty motion vectors: {has_mvs}")
        assert has_mvs, "Motion vector extraction failed: all frames have empty motion vectors!"
        
        # Test filtering
        print("Running test_filtering...")
        test_filtering(temp_video)
        
        print("\nAll assertions PASSED successfully!")
        
    finally:
        # Clean up the downloaded file
        if is_temp and os.path.exists(temp_video):
            os.remove(temp_video)
            print("Cleaned up test video file.")

if __name__ == "__main__":
    main()
