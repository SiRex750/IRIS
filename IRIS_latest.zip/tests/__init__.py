"""
IRIS test suite package.
"""
