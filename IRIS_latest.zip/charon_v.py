import av
import numpy as np
import sys
import pprint


def parse_video(video_path: str, return_stats: bool = False, return_raw: bool = False, candidate_thresh: float = 0.08, salient_thresh: float = 0.35, adaptive: bool = True, **kwargs):
    """
    Parses an H.264 video stream using PyAV and numpy without full RGB decoding.
    Returns a list of dicts for salient frames (I_FRAME, CANDIDATE) only.
    
    If return_stats is True, returns a tuple: (output_frames, stats_dict).
    If return_raw is True, additionally returns a list of raw per-frame records.
    """
    # Pass 1: Collect luma-diff energies of P/B frames
    container = av.open(video_path)
    if not container.streams.video:
        container.close()
        raise ValueError("No video stream found in the container.")
    
    all_frame_energies: list[tuple[int, float]] = []  # (frame_idx, residual_energy)
    energies = []  # existing list, kept for threshold calculation
    total_frames_pass1 = 0
    prev_Y_pass1 = None
    
    try:
        for frame in container.decode(video=0):
            arr = frame.to_ndarray(format='yuv420p')
            current_Y_pass1 = arr[0:frame.height, :]
            
            if total_frames_pass1 == 0:
                residual_energy = 1.0
            else:
                if prev_Y_pass1 is not None:
                    diff = np.abs(current_Y_pass1.astype(float) - prev_Y_pass1.astype(float))
                    residual_energy = float(np.mean(diff) / 255.0)
                else:
                    residual_energy = 1.0
                    
            prev_Y_pass1 = current_Y_pass1.copy()
            
            all_frame_energies.append((total_frames_pass1, residual_energy))
            if not frame.key_frame:
                energies.append(residual_energy)
                
            total_frames_pass1 += 1
    finally:
        container.close()
    
    if adaptive:
        if energies:
            candidate_thresh = float(np.percentile(energies, 90))

    # Second pass (or only pass)
    container = av.open(video_path)
    if not container.streams.video:
        container.close()
        raise ValueError("No video stream found in the container.")
        
    stream = container.streams.video[0]
    
    # Export motion vectors (must set before container.decode starts)
    stream.codec_context.options = {"flags2": "+export_mvs"}
    
    output_frames = []
    raw_records = []
    
    total_frames = 0
    i_frame_count = 0
    peak_count = 0
    salient_count = 0
    candidate_count = 0
    skipped_count = 0
    
    prev_Y = None
    
    try:
        for frame in container.decode(video=0):
            # Y plane extraction
            # yuv420p layout has the Y channel as the first height rows of the numpy array
            arr = frame.to_ndarray(format='yuv420p')
            current_Y = arr[0:frame.height, :]
            
            if total_frames == 0:
                residual_energy = 1.0
            else:
                if prev_Y is not None:
                    # Cast to float to prevent underflow before calculating mean absolute diff
                    diff = np.abs(current_Y.astype(float) - prev_Y.astype(float))
                    residual_energy = float(np.mean(diff) / 255.0)
                else:
                    residual_energy = 1.0
            
            # Keep a copy of current Y for the next iteration's residual proxy calculation
            prev_Y = current_Y.copy()
            
            # Skip logic (non-key-frames below candidate threshold are skipped)
            is_skipped = not frame.key_frame and residual_energy < candidate_thresh
                    
            # Update statistics counters
            if frame.key_frame:
                i_frame_count += 1
            elif not is_skipped:
                candidate_count += 1
            else:
                skipped_count += 1
                
            # Extract motion vectors (empty for I-frames or if not exported/available)
            if frame.key_frame:
                motion_vectors = []
            else:
                motion_vectors = []
                try:
                    for sd in frame.side_data:
                        if getattr(sd.type, 'name', None) == 'MOTION_VECTORS':
                            for mv in sd:
                                motion_vectors.append((
                                    int(mv.src_x),
                                    int(mv.src_y),
                                    int(mv.dst_x),
                                    int(mv.dst_y),
                                    int(mv.motion_x),
                                    int(mv.motion_y)
                                ))
                except (AttributeError, TypeError):
                    motion_vectors = []
                    
            # Calculate robust timestamp
            if frame.time is not None:
                timestamp = float(frame.time)
            elif frame.pts is not None and stream.time_base is not None:
                timestamp = float(frame.pts * stream.time_base)
            else:
                timestamp = 0.0

            # Append to output only if not skipped
            if not is_skipped:
                output_frames.append({
                    "frame_idx": total_frames,
                    "timestamp": timestamp,
                    "residual_energy": residual_energy,
                    "motion_vectors": motion_vectors
                })

            # Expose raw records non-breakingly if requested
            if return_raw:
                pict_type = getattr(frame, "pict_type", None)
                if pict_type is None:
                    frame_type = "I" if frame.key_frame else "P"
                elif isinstance(pict_type, int):
                    try:
                        frame_type = av.video.frame.PictureType(pict_type).name
                    except Exception:
                        frame_type = "I" if frame.key_frame else "P"
                elif hasattr(pict_type, "name"):
                    frame_type = pict_type.name
                else:
                    frame_type = str(pict_type)

                mvs_mags = [np.sqrt(mv[4]**2 + mv[5]**2) for mv in motion_vectors]
                motion_magnitude = float(np.mean(mvs_mags)) if mvs_mags else 0.0
                try:
                    hist, _ = np.histogram(current_Y, bins=256, range=(0, 256), density=True)
                    hist = hist[hist > 0]
                    entropy = float(-np.sum(hist * np.log2(hist))) / 8.0
                except Exception:
                    entropy = 0.0
                
                raw_records.append({
                    "frame_idx": total_frames,
                    "frame_type": frame_type,
                    "residual_energy": residual_energy,
                    "motion_magnitude": motion_magnitude,
                    "entropy": entropy
                })
                
            total_frames += 1
    finally:
        container.close()
    
    stats = {
        "total": total_frames,
        "i_frames": i_frame_count,
        "candidate": candidate_count,
        "skipped": skipped_count,
        "candidate_thresh_used": candidate_thresh
    }
    
    if return_raw:
        if return_stats:
            return output_frames, stats, raw_records
        return output_frames, raw_records
        
    if return_stats:
        return output_frames, stats
    return output_frames

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Parse H.264 video streams.")
    parser.add_argument("video_path", type=str, help="Path to the video file.")
    parser.add_argument("--no-adaptive", action="store_true", help="Force hardcoded thresholds instead of adaptive ones.")
    
    args = parser.parse_args()
    
    try:
        output_frames, stats = parse_video(args.video_path, return_stats=True, adaptive=not args.no_adaptive)
    except Exception as e:
        print(f"Error parsing video: {e}")
        sys.exit(1)
        
    total = stats["total"]
    def pct(count):
        return (count / total * 100) if total > 0 else 0.0
        
    print(f"Total frames: {total}")
    print(f"I-frames: {stats['i_frames']} ({pct(stats['i_frames']):.1f}%)")
    print(f"Candidate: {stats['candidate']} ({pct(stats['candidate']):.1f}%)")
    print(f"Skipped: {stats['skipped']} ({pct(stats['skipped']):.1f}%)")
    print(f"Candidate threshold used: {stats['candidate_thresh_used']:.4f}")
    print(f"Output entries: {len(output_frames)}")
    
    print("\nFirst 5 output entries:")
    for entry in output_frames[:5]:
        pprint.pprint(entry)
